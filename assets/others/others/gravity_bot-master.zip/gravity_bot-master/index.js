const { Client, Intents, MessageEmbed, MessageActionRow, MessageButton, MessageSelectMenu, MessageAttachment , Modal , TextInputComponent } = require("discord.js");
const client = new Client({
    intents: [
        Intents.FLAGS.GUILDS,
        Intents.FLAGS.GUILD_MESSAGES,
        Intents.FLAGS.GUILD_MEMBERS
    ]
});

require("./database/connect");
const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v9');
const { token, clientID, adminsRole, designersRole, programmersRole, highStaffRole, staffRole, crewActivitiesChannel, logsChannel, clientsRole, prefix , discordDesignersRole , animeDesignersRole , twitchDesignersRole , instagramDesignersRole , youtubeDesignersRole , uiDesignersRole , ticketsCategory , closedTicketsCategory , designersWorkChannel } = require("./config.json");
const ticketModel = require("./database/models/ticket");
const designerWorksModel = require("./database/models/designerWork");
const approvedCommandAccess = [adminsRole, "", "", ""];
const highCommandsAccess = [adminsRole, ""];
const staffPermsRoles = [adminsRole, highStaffRole, staffRole, programmersRole, designersRole];
client.setMaxListeners(0);

const commands = [
    {
        name: "add-staff",
        description: "Admins Only",
        options: [
            {
                name: "user",
                description: "mention a user",
                type: "6",
                required: true
            },
            {
                name: "level",
                description: "Choose a level",
                choices: [
                    {
                        name: "designer",
                        value: "designer"
                    },
                    {
                        name: "developer",
                        value: "developer"
                    },
                    {
                        name: "staff",
                        value: "staff"
                    }
                ],
                type: "3",
                required: true
            },
            {
                name: "reason",
                description: "reason for approval",
                type: "3",
                required: true
            }
        ]
    },
    {
        name: 'request',
        description: 'to come Dm someone who doesnt respond in the ticket',
        options: [
            {
                name: 'user',
                description: 'choose a user',
                type: '6',
                required: true
            },
            {
                name: 'reason',
                description: 'reason for request',
                type: '3',
                required: false
            }
        ]
    },
    {
        name: 'talk',
        description: 'to make the bot say something',
        options: [
            {
                name: 'message',
                description: 'message to talk',
                type: '3',
                required: true
            },
            {
                name: 'embed',
                description: 'embed/message',
                type: '5',
                required: true
            },
            {
                name: 'channel',
                description: 'the channel',
                type: '7',
                required: false
            }
        ]
    },
    {
        name: "add-client",
        description: "to add someone to the clients list",
        options: [
            {
                name: "user",
                description: "choose a user",
                type: "6",
                required: true,
            }
        ]
    },
    {
        name: "image",
        description: "to send an image",
        options: [
            {
                name: "image",
                description: "the image link",
                type: "3",
                required: true
            },
            {
                name: 'embed',
                description: 'embed/message',
                type: '5',
                required: true
            },
            {
                name: 'channel',
                description: 'the channel',
                type: '7',
                required: false
            }
        ]
    },
    {
        name: "form",
        description: "to send an form"
    },
    {
        name: "remove-staff",
        description: "to remove someone from the staff list",
        options: [
            {
                name: "user",
                description: "mention a user",
                type: "6",
                required: true
            },
            {
                name: "level",
                description: "Choose a level",
                choices: [
                    {
                        name: "designer",
                        value: "designer"
                    },
                    {
                        name: "developer",
                        value: "developer"
                    },
                    {
                        name: "staff",
                        value: "staff"
                    }
                ],
                type: "3",
                required: true
            },
            {
                name: "reason",
                description: "reason for approval",
                type: "3",
                required: true
            }
        ]
    },
    {
        name: "claim",
        description: "( staff only ) to claim a ticket"
    },
    {
        name: "unclaim",
        description: "( staff only ) to unclaim a ticket"
    },
    {
        name: "rename",
        description: "( staff only ) to rename a ticket",
        options: [
            {
                name: "name",
                description: "enter the new name",
                type: "3",
                required: true
            }
        ]
    },
    {
        name: "close",
        description: "( staff only ) to close a ticket"
    },
    {
        name: "delete",
        description: "( admins only ) to delete a ticket"
    },
    {
        name: "add",
        description: "( staff only ) to add someone to the ticket",
        options: [
            {
                name: "user",
                description: "mention a user",
                type: "6",
                required: true
            }
        ]
    },
    {
        name: "remove",
        description: "( staff only ) to remove someone from the ticket",
        options: [
            {
                name: "user",
                description: "mention a user",
                type: "6",
                required: true
            }
        ]
    },
    {
        name: "show-work",
        description: "( designers only ) to show a your work on the portofolio room",
    },
    {
        name: "view-designer",
        description: "to view an designer work",
        options: [
            {
                name: "user",
                description: "mention an designer",
                type: "6",
                required: true
            }
        ]
    }
];

const rest = new REST({ version: '9' }).setToken(token);

(async () => {
    try {
        console.log('Started refreshing application (/) commands.');
        await rest.put(
            Routes.applicationCommands(clientID),
            { body: commands },
        );
        console.log('Successfully reloaded application (/) commands.');
    } catch (error) {
        console.error(error);
    }
})();


client.on("interactionCreate", async (interaction) => {
    if (!interaction.isCommand()) return;
    if (interaction.commandName === "add-staff") {
        if (!interaction.guild) return;
        if (!interaction.member.roles.cache.some(r => approvedCommandAccess.includes(r.id))) return await interaction.reply({ content: `:warning: **You dont have access to this action**`, ephemeral: true });
        let user = interaction.options.getUser("user");
        let level = interaction.options.getString("level");
        let reason = interaction.options.getString("reason");
        let member = interaction.guild.members.cache.get(user.id);
        if (!member) return await interaction.reply({ content: `:warning: **Member not found**`, ephemeral: true });
        if (level === "designer") {
            if (member.roles.cache.has(designersRole)) return await interaction.reply({ content: `:warning: **This member already has this role**`, ephemeral: true });
            await member.roles.add(designersRole);
            await interaction.reply({ content: `:white_check_mark: <@${member.user.id}> **Has been approved as a designer**`, ephemeral: true });
            let crewActivitiesEmbed = new MessageEmbed()
                .setColor("GREEN")
                .setTitle(`Congratulations :partying_face: , **You have been added to the designers team**`)
                .setFooter({
                    text: interaction.guild.name,
                    avatarURL: interaction.guild.iconURL()
                })
                .setDescription(`Your responsibilities are :
1 - 
2 -
3 -
            `);
            await client.channels.cache.get(crewActivitiesChannel).send({ content: `<@${user.id}>`, embeds: [crewActivitiesEmbed] });
            await client.users.cache.get(user.id).send({ embeds: [crewActivitiesEmbed] }).catch(() => { });
            let logsEmbed = new MessageEmbed()
                .setColor("GREEN")
                .setTitle(`${member.user.tag} has been added to the designers team`)
                .addFields(
                    { name: "User :", value: `<@${member.user.id}> , ${member.user.tag} , (${member.user.id})` },
                    { name: "Responsible :", value: `${interaction.user.tag} , (${interaction.user.id})` },
                    { name: "Level :", value: `${level}` },
                    { name: "Reason :", value: `${reason}` }
                )
                .setTimestamp();
            await interaction.guild.channels.cache.get(logsChannel).send({ content: `<@${user.id}>`, embeds: [logsEmbed] });
        } else if (level === "developer") {
            if (member.roles.cache.has(programmersRole)) return await interaction.reply({ content: `:warning: **This member already has this role**`, ephemeral: true });
            await member.roles.add(programmersRole);
            await interaction.reply({ content: `:white_check_mark: <@${member.user.id}> **Has been approved as a programmer**`, ephemeral: true });
            let crewActivitiesEmbed = new MessageEmbed()
                .setColor("GREEN")
                .setTitle(`Congratulations :partying_face: , **You have been added to the programmers team**`)
                .setFooter({
                    text: interaction.guild.name,
                    iconURL: interaction.guild.iconURL({dynamic: true})
                })
                .setDescription(`Your responsibilities are :
1 -
2 -
3 -
            `);
            await client.channels.cache.get(crewActivitiesChannel).send({ content: `<@${user.id}>`, embeds: [crewActivitiesEmbed] });
            await client.users.cache.get(user.id).send({ embeds: [crewActivitiesEmbed] }).catch(() => { });
            let logsEmbed = new MessageEmbed()
                .setColor("GREEN")
                .setTitle(`${member.user.tag} has been added to the programmers team`)
                .addFields(
                    { name: "User :", value: `<@${member.user.id}> , ${member.user.tag} , (${member.user.id})` },
                    { name: "Responsible :", value: `${interaction.user.tag} , (${interaction.user.id})` },
                    { name: "Level :", value: `${level}` },
                    { name: "Reason :", value: `${reason}` }
                )
                .setTimestamp();
            await interaction.guild.channels.cache.get(logsChannel).send({ content: `<@${user.id}>`, embeds: [logsEmbed] });
        } else if (level === "staff") {
            if (member.roles.cache.has(staffRole)) return await interaction.reply({ content: `:warning: **This member already has this role**`, ephemeral: true });
            await member.roles.add(staffRole);
            await interaction.reply({ content: `:white_check_mark: <@${member.user.id}> **Has been approved as a staff member**`, ephemeral: true });
            let crewActivitiesEmbed = new MessageEmbed()
                .setColor("GREEN")
                .setTitle(`Congratulations :partying_face: , **You have been added to the staff team**`)
                .setFooter({
                    text: interaction.guild.name,
                    iconURL: interaction.guild.iconURL({dynamic: true})
                })
                .setDescription(`Your responsibilities are :
1 -
2 -
3 -
            `);
            await client.channels.cache.get(crewActivitiesChannel).send({ content: `<@${user.id}>`, embeds: [crewActivitiesEmbed] });
            await client.users.cache.get(user.id).send({ embeds: [crewActivitiesEmbed] }).catch(() => { });
            let logsEmbed = new MessageEmbed()
                .setColor("GREEN")
                .setTitle(`${member.user.tag} has been added to the staff team`)
                .addFields(
                    { name: "User :", value: `<@${member.user.id}> , ${member.user.tag} , (${member.user.id})` },
                    { name: "Responsible :", value: `${interaction.user.tag} , (${interaction.user.id})` },
                    { name: "Level :", value: `${level}` },
                    { name: "Reason :", value: `${reason}` }
                )
                .setTimestamp();
            await interaction.guild.channels.cache.get(logsChannel).send({ content: `<@${user.id}>`, embeds: [logsEmbed] });
        }
    }
});

client.on("interactionCreate", async (interaction) => {
    if (!interaction.isCommand()) return;
    if (interaction.commandName === 'request') {
        if (!interaction.guild) return;
        try {
            if (!interaction.member.roles.cache.some(r => approvedCommandAccess.includes(r.id))) return await interaction.reply({ content: `you dont have access to this action`, ephemeral: true });
            let user = interaction.options.getUser('user');
            let reason = interaction.options.getString('reason');
            let member = await interaction.guild.members.fetch(user.id);
            if (!member) return await interaction.reply({ content: `This user is not in this server.`, ephemeral: true });
            if (!reason) {
                reason = "No reason provided";
            }
            let embed = new MessageEmbed()
                .setColor("RED")
                .setDescription(`please come to the ticket ${interaction.channel}`)
                .addFields(
                    { name: "Reason :", value: `${reason}` },
                )
                .setFooter({
                    text: interaction.guild.name,
                    iconURL: interaction.guild.iconURL({dynamic: true})
                })
                .setTimestamp();
            await member.send({ embeds: [embed] });
            await interaction.reply({ content: `:white_check_mark: Sent Successfully`, ephemeral: true });
        } catch (error) {
            await interaction.reply({ content: `:warning: **This user DM is closed.**`, ephemeral: true });
        }
    }
});

client.on("interactionCreate", async (interaction) => {
    if (!interaction.isCommand()) return;
    if (interaction.commandName === 'talk') {
        if (!interaction.guild) return;
        if (!interaction.member.roles.cache.some(r => highCommandsAccess.includes(r.id))) return await interaction.reply({ content: `:warning: **You dont have access to this action**`, ephemeral: true });
        let message = interaction.options.getString('message');
        let type = interaction.options.getBoolean('embed');
        let channel = interaction.options.getChannel('channel');
        if (!channel) {
            channel = interaction.channel;
        }
        if (channel.type !== "GUILD_TEXT") return await interaction.reply({ content: `:warning: **This channel is not an text channel**`, ephemeral: true });
        if (type === true) {
            let embed = new MessageEmbed()
                .setDescription(`${message}`)
                .setFooter({
                    text: interaction.guild.name,
                    iconURL: interaction.guild.iconURL({dynamic: true})
                })
                .setTimestamp();
            await channel.send({ embeds: [embed] });
            await interaction.reply({ content: `:white_check_mark: Sent Successfully`, ephemeral: true });
        } else if (type === false) {
            await channel.send({ content: `${message}` });
            await interaction.reply({ content: `:white_check_mark: Sent Successfully`, ephemeral: true });
        }
    }
});

client.on("interactionCreate", async (interaction) => {
    if (!interaction.isCommand()) return;
    if (interaction.commandName === "add-client") {
        if (!interaction.guild) return;
        if (!interaction.member.roles.cache.some(r => staffPermsRoles.includes(r.id))) return await interaction.reply({ content: `:warning: **You dont have access to this action**`, ephemeral: true });
        let User = interaction.options.getUser("user");
        let Member = interaction.guild.members.cache.get(User.id);
        if (!Member) return interaction.reply({ content: ":warning: **This user is not in this server**", ephemeral: true });
        if (Member.roles.cache.has(clientsRole)) return interaction.reply({ content: ":warning: **This user is already in our clients list**", ephemeral: true });
        await Member.roles.add(clientsRole);
        await interaction.reply({ content: `${User} Have been added to our clients list` });
    }
});

client.on("interactionCreate", async (interaction) => {
    if (!interaction.isCommand()) return;
    if (interaction.commandName === "image") {
        if (!interaction.guild) return;
        if (!interaction.member.roles.cache.some(r => highCommandsAccess.includes(r.id))) return await interaction.reply({ content: `:warning: **You dont have access to this action**`, ephemeral: true });
        let image = interaction.options.getString("image");
        let type = interaction.options.getBoolean("embed");
        let channel = interaction.options.getChannel('channel');
        if (!channel) {
            channel = interaction.channel;
        }
        if (channel.type !== "GUILD_TEXT") return await interaction.reply({ content: `:warning: **This channel is not an text channel**`, ephemeral: true });
        if (!image.startsWith("https://")) return await interaction.reply({ content: `:warning: **This is not an valid image**`, ephemeral: true });
        let formats = ["jpg", "jpeg", "png", "gif"];
        let format = image.split(".").pop();
        if (!formats.includes(format)) return await interaction.reply({ content: `:warning: **Enter an valid format**`, ephemeral: true });
        if (type === true) {
            let embed = new MessageEmbed()
                .setImage(`${image}`);
            await channel.send({ embeds: [embed] });
            await interaction.reply({ content: `:white_check_mark: Sent Successfully`, ephemeral: true });
        } else if (type === false) {
            await channel.send({ content: `${image}` });
            await interaction.reply({ content: `:white_check_mark: Sent Successfully`, ephemeral: true });
        }
    }
});

client.on("interactionCreate", async (interaction) => {
    if (!interaction.isCommand()) return;
    if (interaction.commandName === "form") {
        if (!interaction.guild) return;
        if (!interaction.member.roles.cache.some(r => staffPermsRoles.includes(r.id))) return await interaction.reply({ content: `:warning: **You dont have access to this action**`, ephemeral: true });
        if (interaction.channel.parentId !== "1007063700793999493") return await interaction.reply({ content: `:warning: **This command is for tickets only**`, ephemeral: true });
        let embed = new MessageEmbed()
            .setDescription(`some text here`)
            .setImage(`https://images-ext-2.discordapp.net/external/V5xWuQzncSX1k0iDj0oCZJmYy4PNCf27cyyEK2XIJkY/%3Fsize%3D4096/https/cdn.discordapp.com/avatars/744183251102335007/625efbf5e221fb5377d10c9c77ee8733.png`)
            .setFooter({
                text: interaction.guild.name,
                iconURL: interaction.guild.iconURL({dynamic: true})
            })
            .setTimestamp();
        await interaction.channel.send({ embeds: [embed] });
        await interaction.reply({ content: `:white_check_mark: Done`, ephemeral: true });
    }
});

client.on("interactionCreate", async (interaction) => {
    if (!interaction.isCommand()) return;
    if (interaction.commandName === "remove-staff") {
        if (!interaction.guild) return;
        if (!interaction.member.roles.cache.some(r => approvedCommandAccess.includes(r.id))) return await interaction.reply({ content: `:warning: **You dont have access to this action**`, ephemeral: true });
        let user = interaction.options.getUser("user");
        let level = interaction.options.getString("level");
        let reason = interaction.options.getString("reason");
        let member = interaction.guild.members.cache.get(user.id);
        if (!member) return await interaction.reply({ content: `:warning: **Member not found**`, ephemeral: true });
        if (level === "designer") {
            if (!member.roles.cache.has(designersRole)) return await interaction.reply({ content: `:warning: **This member is not a designer**`, ephemeral: true });
            await member.roles.remove(designersRole);
            await interaction.reply({ content: `:white_check_mark: <@${member.user.id}> **Has been removed from the designers team**`, ephemeral: true });
            let crewActivitiesEmbed = new MessageEmbed()
                .setColor("RED")
                .setTitle(`**You have been removed from the designers team**`)
                .setFooter({
                    text: interaction.guild.name,
                    iconURL: interaction.guild.iconURL({dynamic: true})
                });
            await client.channels.cache.get(crewActivitiesChannel).send({ content: `<@${user.id}>`, embeds: [crewActivitiesEmbed] });
            await client.users.cache.get(user.id).send({ embeds: [crewActivitiesEmbed] }).catch(() => { });
            let logsEmbed = new MessageEmbed()
                .setColor("RED")
                .setTitle(`${member.user.tag} has been removed from the designers team`)
                .addFields(
                    { name: "User :", value: `<@${member.user.id}> , ${member.user.tag} , (${member.user.id})` },
                    { name: "Responsible :", value: `${interaction.user.tag} , (${interaction.user.id})` },
                    { name: "Level :", value: `${level}` },
                    { name: "Reason :", value: `${reason}` }
                )
                .setFooter({
                    text: interaction.guild.name,
                    iconURL: interaction.guild.iconURL({dynamic: true})
                })
                .setTimestamp();
            await interaction.guild.channels.cache.get(logsChannel).send({ content: `<@${user.id}>`, embeds: [logsEmbed] });
        } else if (level === "developer") {
            if (!member.roles.cache.has(programmersRole)) return await interaction.reply({ content: `:warning: **This member is not a developer**`, ephemeral: true });
            await member.roles.remove(programmersRole);
            await interaction.reply({ content: `:white_check_mark: <@${member.user.id}> **Has been removed from the developers team**`, ephemeral: true });
            let crewActivitiesEmbed = new MessageEmbed()
                .setColor("RED")
                .setTitle(`**You have been removed from the developers team**`)
                .setFooter({
                    text: interaction.guild.name,
                    iconURL: interaction.guild.iconURL({dynamic: true})
                });
            await client.channels.cache.get(crewActivitiesChannel).send({ content: `<@${user.id}>`, embeds: [crewActivitiesEmbed] });
            await client.users.cache.get(user.id).send({ embeds: [crewActivitiesEmbed] }).catch(() => { });
            let logsEmbed = new MessageEmbed()
                .setColor("RED")
                .setTitle(`${member.user.tag} has been removed from the developers team`)
                .addFields(
                    { name: "User :", value: `<@${member.user.id}> , ${member.user.tag} , (${member.user.id})` },
                    { name: "Responsible :", value: `${interaction.user.tag} , (${interaction.user.id})` },
                    { name: "Level :", value: `${level}` },
                    { name: "Reason :", value: `${reason}` }
                )
                .setFooter({
                    text: interaction.guild.name,
                    iconURL: interaction.guild.iconURL({dynamic: true})
                })
                .setTimestamp();
            await interaction.guild.channels.cache.get(logsChannel).send({ content: `<@${user.id}>`, embeds: [logsEmbed] });
        } else if (level === "staff") {
            let allStaffRoles = [staffRole, highStaffRole];
            for (let i = 0; i < allStaffRoles.length; i++) {
                await member.roles.remove(allStaffRoles[i]);
            }
            await interaction.reply({ content: `:white_check_mark: <@${member.user.id}> **Has been removed from the staff team**`, ephemeral: true });
            let crewActivitiesEmbed = new MessageEmbed()
                .setColor("RED")
                .setTitle(`**You have been removed from the staff team**`)
                .setFooter({
                    text: interaction.guild.name,
                    iconURL: interaction.guild.iconURL({dynamic: true})
                });
            await client.channels.cache.get(crewActivitiesChannel).send({ content: `<@${user.id}>`, embeds: [crewActivitiesEmbed] });
            await client.users.cache.get(user.id).send({ embeds: [crewActivitiesEmbed] }).catch(() => { });
            let logsEmbed = new MessageEmbed()
                .setColor("RED")
                .setTitle(`${member.user.tag} has been removed from the staff team`)
                .addFields(
                    { name: "User :", value: `<@${member.user.id}> , ${member.user.tag} , (${member.user.id})` },
                    { name: "Responsible :", value: `${interaction.user.tag} , (${interaction.user.id})` },
                    { name: "Level :", value: `${level}` },
                    { name: "Reason :", value: `${reason}` }
                )
                .setFooter({
                    text: interaction.guild.name,
                    iconURL: interaction.guild.iconURL({dynamic: true})
                })
                .setTimestamp();
            await interaction.guild.channels.cache.get(logsChannel).send({ content: `<@${user.id}>`, embeds: [logsEmbed] });
        }
    }
});

client.on("messageCreate", async (message) => {
    if (message.content.startsWith(prefix + "setup-tickets")) {
        if (!message.guild) return;
        if (!message.member.roles.cache.has(adminsRole)) return;
        message.delete();
        let ticketActionRow = new MessageActionRow()
            .addComponents(
                new MessageButton()
                    .setCustomId('orderButton')
                    .setLabel('Order From Here')
                    .setStyle('SUCCESS'),
            )
        await message.channel.send({components: [ticketActionRow]});
    }
});

client.on("interactionCreate" , async (interaction) => {
    if (!interaction.isButton()) return;
    if (interaction.customId === "orderButton") {
        if (!interaction.guild) return;
        let ordersRow = new MessageActionRow()
        .addComponents(
            new MessageSelectMenu()
                .setCustomId('ordersRow')
                .setPlaceholder('Order From Here')
                .addOptions([
                    {
                        label: 'Discord',
                        description: 'To order an discord design',
                        value: 'discord_value',
                    },
                    {
                        label: 'Anime',
                        description: 'To order an anime design',
                        value: 'anime_value',
                    },
                    {
                        label: 'Twitch',
                        description: 'To order a twitch design',
                        value: 'twitch_value',
                    },
                    {
                        label: 'Instagram',
                        description: 'to order an instagram design',
                        value: 'instagram_value',
                    },
                    {
                        label: 'YouTube',
                        description: 'To order a youtube design',
                        value: 'youtube_value',
                    },
                    {
                        label: 'User Interface ( UI )',
                        description: 'To order an UI design',
                        value: 'ui_value',
                    },
                    {
                        label: 'Other',
                        description: 'To order an other stuff',
                        value: 'other_value',
                    }
                ]),
        );
        await interaction.reply({components: [ordersRow] , ephemeral: true});
    }
});

client.on("interactionCreate" , async (interaction) => {
    if(!interaction.isSelectMenu()) return;
    if (interaction.customId === "ordersRow") {
        let ticketData = await ticketModel.findOne({userID: interaction.user.id});
        if (ticketData) {
            if (ticketData.closed === false) return await interaction.reply({content: `You have an opened ticket , <#${ticketData.channelID}>` , ephemeral: true});
        }
        let replacement = interaction.values[0].replace("_value", "");
        let orderGetter = [];
        if (replacement === "discord") {
            orderGetter.push(discordDesignersRole);
        } else if (replacement === "anime") {
            orderGetter.push(animeDesignersRole);
        } else if (replacement === "twitch") {
            orderGetter.push(twitchDesignersRole);
        } else if (replacement === "instagram") {
            orderGetter.push(instagramDesignersRole);
        } else if (replacement === "youtube") {
            orderGetter.push(youtubeDesignersRole);
        } else if (replacement === "ui") {
            orderGetter.push(uiDesignersRole);
        } else if (replacement === "other") {
            orderGetter.push(designersRole);
        }
        let embed = new MessageEmbed()
            .setColor("GREEN")
            .setDescription(`Please wait one of our ${replacement} designers to respond.`)
            .setFooter({
                text: interaction.guild.name,
                iconURL: interaction.guild.iconURL({dynamic: true})
            })
            .setTimestamp();
            let orderActionRow = new MessageActionRow()
            .addComponents(
                new MessageButton()
                    .setCustomId('claimButton')
                    .setLabel('Claim')
                    .setStyle('SUCCESS')
            )
            .addComponents(
                new MessageButton()
                    .setCustomId('closeButton')
                    .setLabel('Close')
                    .setStyle('DANGER')
            );
        await interaction.update({content: `:hourglass: **Please wait while creating your ticket.**` , components: [] , ephemeral: true});
        await interaction.guild.channels.create(`${replacement}-order`, {
            type: 'GUILD_TEXT',
            parent: ticketsCategory,
            permissionOverwrites: [
                {
                    id: interaction.guild.roles.everyone,
                    deny:["VIEW_CHANNEL"]
                },
                {
                    id: interaction.user.id,
                    allow: ["SEND_MESSAGES" , "VIEW_CHANNEL"],
                },
                {
                    id : staffRole,
                    allow: ["SEND_MESSAGES" , "VIEW_CHANNEL"],
                },
                {
                    id: orderGetter.toString(),
                    allow: ["SEND_MESSAGES" , "VIEW_CHANNEL"],
                }
            ]
        }).then(async (ticketChannel) => {
            await ticketChannel.send({content: `Customer : <@${interaction.user.id}> , Order : ${replacement}` , embeds: [embed] , components: [orderActionRow]});
            await interaction.editReply({content: `:white_check_mark: **Your ticket has been created** , ${ticketChannel}` , ephemeral: true});
            await ticketChannel.messages.fetch({ limit: 1 }).then(async(messages) => {
                let ticketMessage = messages.first();
                ticketMessage.pin();
                let ticket = new ticketModel({
                    userID: interaction.user.id,
                    channelID: ticketMessage.channel.id,
                    messageID: ticketMessage.id,
                    designersOrderRole: orderGetter.toString(),
                    closed: false,
                    order: `${replacement}`
                });
                await ticket.save();
            });
        });
    }
});

client.on("interactionCreate" , async (interaction) => {
    if (!interaction.isButton()) return;
    if (interaction.customId === "claimButton") {
        if (!interaction.guild) return;
        if (!interaction.member.roles.cache.some(r => staffPermsRoles.includes(r.id))) return await interaction.reply({ content: `:warning: **You dont have access to this action**`, ephemeral: true });
        let ticketData = await ticketModel.findOne({channelID: interaction.channel.id});
        if (!ticketData) return await interaction.reply({content: `:warning: **This channel is not a ticket.**` , ephemeral: true});
        if (ticketData.closed === true) return await interaction.reply({content: `:warning: **This ticket is closed.**` , ephemeral: true});
        if (ticketData.cliamedBy === interaction.user.id) return await interaction.reply({content: `:warning: **You already claimed this ticket.**` , ephemeral: true});
        if (ticketData.cliamedBy) return await interaction.reply({content: `:warning: **This ticket is already claimed by <@${ticketData.cliamedBy}>**` , ephemeral: true});
        await ticketModel.findOneAndUpdate({channelID: interaction.channel.id} , {cliamedBy: interaction.user.id});
        await interaction.channel.setName(`${interaction.user.username}-${ticketData.order}`);
        let embed = new MessageEmbed()
            .setColor("GREEN")
            .setDescription(`${interaction.user} Claimed this ticket.`)
            .setFooter({
                text: interaction.guild.name,
                iconURL: interaction.guild.iconURL({dynamic: true})
            })
            .setTimestamp();
            let ActionRow = new MessageActionRow()
            .addComponents(
                new MessageButton()
                    .setCustomId('unclaimButton')
                    .setLabel('Unclaim')
                    .setStyle('DANGER')
            );
        await interaction.channel.send({embeds: [embed] , components: [ActionRow]});
        await interaction.reply({content: `:white_check_mark: **You have claimed this ticket successfully**` , ephemeral: true});
        let logsEmbed = new MessageEmbed()
            .setColor("GREEN")
            .setTitle(`**An ticket has been claimed**`)
            .addFields(
                { name: `**Ticket Channel**` , value: `<#${interaction.channel.id}> ( ${interaction.channel.name} )` },
                { name: `**Claimed By**` , value: `<@${interaction.user.id}> ( ${interaction.user.tag} ) ( ${interaction.user.id} )` },
                { name: `**Claimed ٍSince**` , value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>` },
                { name: `**Ticket Owner**` , value: `<@${ticketData.userID}> ( ${ticketData.userID} )` },
                { name: `**Ticket Order**` , value: `${ticketData.order}` }
            )
            .setFooter({
                text: interaction.guild.name,
                iconURL: interaction.guild.iconURL({dynamic: true})
            })
            .setTimestamp();
        await client.channels.cache.get(logsChannel).send({embeds: [logsEmbed]});
    }
});

client.on("interactionCreate" , async (interaction) => {
    if (!interaction.isCommand()) return;
    if (interaction.commandName === "unclaim") {
        if (!interaction.guild) return;
        if (!interaction.member.roles.cache.some(r => staffPermsRoles.includes(r.id))) return await interaction.reply({ content: `:warning: **You dont have access to this action**`, ephemeral: true });
        let ticketData = await ticketModel.findOne({channelID: interaction.channel.id});
        if (!ticketData) return await interaction.reply({content: `:warning: **This channel is not a ticket.**` , ephemeral: true});
        if (ticketData.closed === true) return await interaction.reply({content: `:warning: **This ticket is closed.**` , ephemeral: true});
        if (ticketData.cliamedBy !== interaction.user.id) return await interaction.reply({content: `:warning: **You didn't claim this ticket.**` , ephemeral: true});
        await ticketModel.findOneAndUpdate({channelID: interaction.channel.id} , {cliamedBy: null});
        await interaction.channel.setName(`${ticketData.order}-order`);
        let embed = new MessageEmbed()
            .setColor("RED")
            .setDescription(`${interaction.user} Unclaimed this ticket.`)
            .setFooter({
                text: interaction.guild.name,
                iconURL: interaction.guild.iconURL({dynamic: true})
            })
            .setTimestamp();
        await interaction.channel.send({embeds: [embed]});
        await interaction.reply({content: `:white_check_mark: **You have unclaimed this ticket successfully**` , ephemeral: true});
        let logsEmbed = new MessageEmbed()
            .setColor("RED")
            .setTitle(`**An ticket has been unclaimed**`)
            .addFields(
                { name: `**Ticket Channel**` , value: `<#${interaction.channel.id}> ( ${interaction.channel.name} )` },
                { name: `**Unclaimed By**` , value: `<@${interaction.user.id}> ( ${interaction.user.tag} ) ( ${interaction.user.id} )` },
                { name: `**Unclaimed ٍSince**` , value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>` },
                { name: `**Ticket Owner**` , value: `<@${ticketData.userID}> ( ${ticketData.userID} )` },
                { name: `**Ticket Order**` , value: `${ticketData.order}` }
            )
            .setFooter({
                text: interaction.guild.name,
                iconURL: interaction.guild.iconURL({dynamic: true})
            })
            .setTimestamp();
        await client.channels.cache.get(logsChannel).send({embeds: [logsEmbed]});
    }
});

client.on("interactionCreate" , async(interaction) =>{
    if (!interaction.isButton()) return;
    if (interaction.customId === 'unclaimButton') {
        let ticketData = await ticketModel.findOne({channelID: interaction.channel.id});
        if (!ticketData) return await interaction.reply({content: `:warning: **This channel is not a ticket.**` , ephemeral: true});
        if (ticketData.closed === true) return await interaction.reply({content: `:warning: **This ticket is closed.**` , ephemeral: true});
        if (ticketData.cliamedBy !== interaction.user.id) return await interaction.reply({content: `:warning: **You didn't claim this ticket.**` , ephemeral: true});
        await ticketModel.findOneAndUpdate({channelID: interaction.channel.id} , {cliamedBy: null});
        await interaction.channel.setName(`${ticketData.order}-order`);
        let embed = new MessageEmbed()
            .setColor("RED")
            .setDescription(`${interaction.user} Unclaimed this ticket.`)
            .setFooter({
                text: interaction.guild.name,
                iconURL: interaction.guild.iconURL({dynamic: true})
            })
            .setTimestamp();
        await interaction.channel.send({embeds: [embed]});
        await interaction.reply({content: `:white_check_mark: **You have unclaimed this ticket successfully**` , ephemeral: true});
        let logsEmbed = new MessageEmbed()
            .setColor("RED")
            .setTitle(`**An ticket has been unclaimed**`)
            .addFields(
                { name: `**Ticket Channel**` , value: `<#${interaction.channel.id}> ( ${interaction.channel.name} )` },
                { name: `**Unclaimed By**` , value: `<@${interaction.user.id}> ( ${interaction.user.tag} ) ( ${interaction.user.id} )` },
                { name: `**Unclaimed ٍSince**` , value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>` },
                { name: `**Ticket Owner**` , value: `<@${ticketData.userID}> ( ${ticketData.userID} )` },
                { name: `**Ticket Order**` , value: `${ticketData.order}` }
            )
            .setFooter({
                text: interaction.guild.name,
                iconURL: interaction.guild.iconURL({dynamic: true})
            })
            .setTimestamp();
        await client.channels.cache.get(logsChannel).send({embeds: [logsEmbed]});
    }
});

client.on("interactionCreate" , async (interaction) => {
    if (!interaction.isButton()) return;
    if (interaction.customId === "closeButton") {
        if (!interaction.guild) return;
        if (!interaction.member.roles.cache.some(r => staffPermsRoles.includes(r.id))) return await interaction.reply({ content: `:warning: **You dont have access to this action**`, ephemeral: true });
        let ticketData = await ticketModel.findOne({channelID: interaction.channel.id});
        if (!ticketData) return await interaction.reply({content: `:warning: **This channel is not a ticket.**` , ephemeral: true});
        if (ticketData.closed === true) return await interaction.reply({content: `:warning: **This ticket is already closed.**` , ephemeral: true});
        await interaction.channel.edit({
            parent: closedTicketsCategory,
            permissionOverwrites: [
                {
                    id: interaction.guild.roles.everyone,
                    deny:["VIEW_CHANNEL"]
                },
                {
                    id: ticketData.userID,
                    deny:["VIEW_CHANNEL"]
                },
                {
                    id: designersRole,
                    deny: ["SEND_MESSAGES" , "VIEW_CHANNEL"]
                },
                {
                    id: staffRole,
                    deny: ["SEND_MESSAGES" , "VIEW_CHANNEL"]
                }
            ]
        }).then(async () => {
            await ticketModel.findOneAndUpdate({channelID: interaction.channel.id} , {closed: true});
            await interaction.channel.setName(`${ticketData.order}-closed`);
            let closedTicketActionRow = new MessageActionRow()
                .addComponents(
                    new MessageButton()
                        .setCustomId("reopenButton")
                        .setLabel("Reopen")
                        .setStyle("SUCCESS")
                )
                .addComponents(
                    new MessageButton()
                        .setCustomId("deleteButton")
                        .setLabel("Delete")
                        .setStyle("DANGER")
                );
            let embed = new MessageEmbed()
                .setColor("RED")
                .setDescription(`${interaction.user} Closed this ticket.`)
                .setFooter({
                    text: interaction.guild.name,
                    iconURL: interaction.guild.iconURL({dynamic: true})
                })
                .setTimestamp();
            await interaction.channel.send({embeds: [embed] , components: [closedTicketActionRow]});
            await interaction.reply({content: `:white_check_mark: **You have closed this ticket successfully**` , ephemeral: true});
            let logsEmbed = new MessageEmbed()
                .setColor("RED")
                .setTitle(`**An ticket has been closed**`)
                .addFields(
                    { name: `**Ticket Channel**` , value: `<#${interaction.channel.id}> ( ${interaction.channel.name} )` },
                    { name: `**Closed By**` , value: `<@${interaction.user.id}> ( ${interaction.user.tag} ) ( ${interaction.user.id} )` },
                    { name: `**Closed Since**` , value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>` },
                    { name: `**Ticket Owner**` , value: `<@${ticketData.userID}> ( ${ticketData.userID} )` },
                    { name: `**Ticket Order**` , value: `${ticketData.order}` }
                )
                .setFooter({
                    text: interaction.guild.name,
                    iconURL: interaction.guild.iconURL({dynamic: true})
                })
                .setTimestamp();
            await client.channels.cache.get(logsChannel).send({embeds: [logsEmbed]});
        });
    }
});

client.on("interactionCreate" , async (interaction) => {
    if (!interaction.isButton()) return;
    if (interaction.customId === "reopenButton") {
        if (!interaction.guild) return;
        if (!interaction.member.roles.cache.some(r => staffPermsRoles.includes(r.id))) return await interaction.reply({ content: `:warning: **You dont have access to this action**`, ephemeral: true });
        let ticketData = await ticketModel.findOne({channelID: interaction.channel.id});
        if (!ticketData) return await interaction.reply({content: `:warning: **This channel is not a ticket.**` , ephemeral: true});
        if (ticketData.closed === false) return await interaction.reply({content: `:warning: **This ticket is already opened.**` , ephemeral: true});
        await interaction.channel.edit({
            parent: ticketsCategory,
            permissionOverwrites: [
                {
                    id: interaction.guild.roles.everyone,
                    deny:["VIEW_CHANNEL"]
                },
                {
                    id: ticketData.userID,
                    allow:["VIEW_CHANNEL"]
                },
                {
                    id: ticketData.designersOrderRole,
                    allow: ["SEND_MESSAGES" , "VIEW_CHANNEL"]
                },
                {
                    id: staffRole,
                    allow: ["SEND_MESSAGES" , "VIEW_CHANNEL"]
                }
            ]
        }).then(async () => {
            await ticketModel.findOneAndUpdate({channelID: interaction.channel.id} , {closed: false});
            await interaction.channel.setName(`${ticketData.order}-order`);
            let embed = new MessageEmbed()
                .setColor("GREEN")
                .setDescription(`${interaction.user} Reopened this ticket.`)
                .setFooter({
                    text: interaction.guild.name,
                    iconURL: interaction.guild.iconURL({dynamic: true})
                })
                .setTimestamp();
            await interaction.channel.send({embeds: [embed]});
            await interaction.reply({content: `:white_check_mark: **You have reopened this ticket successfully**` , ephemeral: true});
            let logsEmbed = new MessageEmbed()
                .setColor("GREEN")
                .setTitle(`**An ticket has been reopened**`)
                .addFields(
                    { name: `**Ticket Channel**` , value: `<#${interaction.channel.id}> ( ${interaction.channel.name} )` },
                    { name: `**Reopened By**` , value: `<@${interaction.user.id}> ( ${interaction.user.tag} ) ( ${interaction.user.id} )` },
                    { name: `**Reopened Since**` , value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>` },
                    { name: `**Ticket Owner**` , value: `<@${ticketData.userID}> ( ${ticketData.userID} )` },
                    { name: `**Ticket Order**` , value: `${ticketData.order}` }
                )
                .setFooter({
                    text: interaction.guild.name,
                    iconURL: interaction.guild.iconURL({dynamic: true})
                })
                .setTimestamp();
            await client.channels.cache.get(logsChannel).send({embeds: [logsEmbed]});
        });
    }
});

client.on("interactionCreate" , async (interaction) => {
    if (!interaction.isButton()) return;
    if (interaction.customId === "deleteButton") {
        if (!interaction.guild) return;
        if (!interaction.member.roles.cache.has(adminsRole)) return await interaction.reply({ content: `:warning: **You dont have access to do this action**`, ephemeral: true });
        let ticketData = await ticketModel.findOne({channelID: interaction.channel.id});
        if (!ticketData) return await interaction.reply({content: `:warning: **This channel is not a ticket.**` , ephemeral: true});
        await interaction.reply({content: ":warning: **This ticket will be deleted in 5s**"});
        await ticketData.delete();
        setTimeout(async() => {
            await interaction.channel.delete();
        } , 5000);
        let logsEmbed = new MessageEmbed()
            .setColor("RED")
            .setTitle(`**An ticket has been deleted**`)
            .addFields(
                { name: `**Ticket Channel**` , value: `<#${interaction.channel.id}> ( ${interaction.channel.name} )` },
                { name: `**Deleted By**` , value: `<@${interaction.user.id}> ( ${interaction.user.tag} ) ( ${interaction.user.id} )` },
                { name: `**Deleted Since**` , value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>` },
                { name: `**Ticket Owner**` , value: `<@${ticketData.userID}> ( ${ticketData.userID} )` },
                { name: `**Ticket Order**` , value: `${ticketData.order}` }
            )
            .setFooter({
                text: interaction.guild.name,
                iconURL: interaction.guild.iconURL({dynamic: true})
            })
            .setTimestamp();
        await client.channels.cache.get(logsChannel).send({embeds: [logsEmbed]});
    }
});

client.on("interactionCreate" , async (interaction) => {
    if (!interaction.isCommand()) return;
    if (interaction.commandName === "rename") {
        if (!interaction.guild) return;
        if (!interaction.member.roles.cache.some(r => staffPermsRoles.includes(r.id))) return await interaction.reply({ content: `:warning: **You dont have access to this action**`, ephemeral: true });
        let ticketData = await ticketModel.findOne({channelID: interaction.channel.id});
        if (!ticketData) return await interaction.reply({content: `:warning: **This channel is not a ticket.**` , ephemeral: true});
        let newName = interaction.options.getString("name");
        await interaction.channel.setName(`${newName}`);
        await interaction.reply({content: `:white_check_mark: **You have renamed this ticket to \`${newName}\`**` , ephemeral: true});
        let logsEmbed = new MessageEmbed()
            .setColor("YELLOW")
            .setTitle(`**An ticket has been renamed**`)
            .addFields(
                { name: `**Ticket Channel**` , value: `<#${interaction.channel.id}> ( ${interaction.channel.name} )` },
                { name: `**Renamed By**` , value: `<@${interaction.user.id}> ( ${interaction.user.tag} ) ( ${interaction.user.id} )` },
                { name: `**Renamed Since**` , value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>` },
                { name: `**Ticket Owner**` , value: `<@${ticketData.userID}> ( ${ticketData.userID} )` },
                { name: `**Ticket Order**` , value: `${ticketData.order}` }
            )
        .setFooter({
            text: interaction.guild.name,
            iconURL: interaction.guild.iconURL({dynamic: true})
        })
        .setTimestamp();
        await client.channels.cache.get(logsChannel).send({embeds: [logsEmbed]});
    }
});

client.on("interactionCreate" , async (interaction) => {
    if (!interaction.isCommand()) return;
    if (interaction.commandName === "add") {
        if (!interaction.guild) return;
        if (!interaction.member.roles.cache.some(r => staffPermsRoles.includes(r.id))) return await interaction.reply({ content: `:warning: **You dont have access to this action**`, ephemeral: true });
        let ticketData = await ticketModel.findOne({channelID: interaction.channel.id});
        if (!ticketData) return await interaction.reply({content: `:warning: **This channel is not a ticket.**` , ephemeral: true});
        let user = interaction.options.getUser("user");
        let member = interaction.guild.members.cache.get(user.id);
        if (!member) return await interaction.reply({content: `:warning: **This user is not in the server.**` , ephemeral: true});
        await interaction.channel.permissionOverwrites.create(user.id , {
            VIEW_CHANNEL: true,
            SEND_MESSAGES: true
        });
        let addEmbed = new MessageEmbed()
            .setColor("GREEN")
            .setDescription(`<@${user.id}> **You have been added to this ticket by** <@${interaction.user.id}>`)
            .setFooter({
                text: interaction.guild.name,
                iconURL: interaction.guild.iconURL({dynamic: true})
            })
            .setTimestamp();
        await interaction.channel.send({embeds: [addEmbed]})
        await interaction.reply({content: `:white_check_mark: **You have added <@${user.id}> to this ticket**` , ephemeral: true});
        let logsEmbed = new MessageEmbed()
            .setColor("GREEN")
            .setTitle(`**Some one has been added to a ticket**`)
            .addFields(
                { name: `**Ticket Channel**` , value: `<#${interaction.channel.id}> ( ${interaction.channel.name} )` },
                { name: `**User**` , value: `<@${user.id}> ( ${user.tag} ) ( ${user.id} )` },
                { name: `**Added By**` , value: `<@${interaction.user.id}> ( ${interaction.user.tag} ) ( ${interaction.user.id} )` },
                { name: `**Added Since**` , value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>` },
                { name: `**Ticket Owner**` , value: `<@${ticketData.userID}> ( ${ticketData.userID} )` },
                { name: `**Ticket Order**` , value: `${ticketData.order}` },
            )
        .setFooter({
            text: interaction.guild.name,
            iconURL: interaction.guild.iconURL({dynamic: true})
        })
        .setTimestamp();
        await client.channels.cache.get(logsChannel).send({embeds: [logsEmbed]});
    }
});

client.on("interactionCreate" , async (interaction) => {
    if (!interaction.isCommand()) return;
    if (interaction.commandName === "remove") {
        if (!interaction.guild) return;
        if (!interaction.member.roles.cache.some(r => staffPermsRoles.includes(r.id))) return await interaction.reply({ content: `:warning: **You dont have access to this action**`, ephemeral: true });
        let ticketData = await ticketModel.findOne({channelID: interaction.channel.id});
        if (!ticketData) return await interaction.reply({content: `:warning: **This channel is not a ticket.**` , ephemeral: true});
        let user = interaction.options.getUser("user");
        let member = interaction.guild.members.cache.get(user.id);
        if (!member) return await interaction.reply({content: `:warning: **This user is not in the server.**` , ephemeral: true});
        await interaction.channel.permissionOverwrites.create(user.id , {
            VIEW_CHANNEL: false,
        });
        let removeEmbed = new MessageEmbed()
            .setColor("RED")
            .setDescription(`<@${interaction.user.id}> **Removed** <@${user.id}> **from this ticket.**`)
            .setFooter({
                text: interaction.guild.name,
                iconURL: interaction.guild.iconURL({dynamic: true})
            })
            .setTimestamp();
        await interaction.channel.send({embeds: [removeEmbed]})
        await interaction.reply({content: `:white_check_mark: **You have removed <@${user.id}> from this ticket**` , ephemeral: true});
        let logsEmbed = new MessageEmbed()
            .setColor("RED")
            .setTitle(`**Some one has been removed from a ticket**`)
            .addFields(
                { name: `**Ticket Channel**` , value: `<#${interaction.channel.id}> ( ${interaction.channel.name} )` },
                { name: `**User**` , value: `<@${user.id}> ( ${user.tag} ) ( ${user.id} )` },
                { name: `**Removed By**` , value: `<@${interaction.user.id}> ( ${interaction.user.tag} ) ( ${interaction.user.id} )` },
                { name: `**Removed Since**` , value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>` },
                { name: `**Ticket Owner**` , value: `<@${ticketData.userID}> ( ${ticketData.userID} )` },
                { name: `**Ticket Order**` , value: `${ticketData.order}` },
            )
        .setFooter({
            text: interaction.guild.name,
            iconURL: interaction.guild.iconURL({dynamic: true})
        })
        .setTimestamp();
        await client.channels.cache.get(logsChannel).send({embeds: [logsEmbed]});
    }
});

client.on("interactionCreate" , async (interaction) => {
    if (!interaction.isCommand()) return;
    if (interaction.commandName === "close") {
        if (!interaction.guild) return;
        if (!interaction.member.roles.cache.some(r => staffPermsRoles.includes(r.id))) return await interaction.reply({ content: `:warning: **You dont have access to this action**`, ephemeral: true });
        let ticketData = await ticketModel.findOne({channelID: interaction.channel.id});
        if (!ticketData) return await interaction.reply({content: `:warning: **This channel is not a ticket.**` , ephemeral: true});
        if (ticketData.closed === true) return await interaction.reply({content: `:warning: **This ticket is already closed.**` , ephemeral: true});
        await interaction.channel.edit({
            parent: closedTicketsCategory,
            permissionOverwrites: [
                {
                    id: interaction.guild.roles.everyone,
                    deny:["VIEW_CHANNEL"]
                },
                {
                    id: ticketData.userID,
                    deny:["VIEW_CHANNEL"]
                },
                {
                    id: designersRole,
                    deny: ["SEND_MESSAGES" , "VIEW_CHANNEL"]
                },
                {
                    id: staffRole,
                    deny: ["SEND_MESSAGES" , "VIEW_CHANNEL"]
                }
            ]
        }).then(async () => {
            await ticketModel.findOneAndUpdate({channelID: interaction.channel.id} , {closed: true});
            await interaction.channel.setName(`${ticketData.order}-closed`);
            let closedTicketActionRow = new MessageActionRow()
                .addComponents(
                    new MessageButton()
                        .setCustomId("reopenButton")
                        .setLabel("Reopen")
                        .setStyle("SUCCESS")
                )
                .addComponents(
                    new MessageButton()
                        .setCustomId("deleteButton")
                        .setLabel("Delete")
                        .setStyle("DANGER")
                );
            let embed = new MessageEmbed()
                .setColor("RED")
                .setDescription(`${interaction.user} Closed this ticket.`)
                .setFooter({
                    text: interaction.guild.name,
                    iconURL: interaction.guild.iconURL({dynamic: true})
                })
                .setTimestamp();
            await interaction.channel.send({embeds: [embed] , components: [closedTicketActionRow]});
            await interaction.reply({content: `:white_check_mark: **You have closed this ticket successfully**` , ephemeral: true});
            let logsEmbed = new MessageEmbed()
                .setColor("RED")
                .setTitle(`**An ticket has been closed**`)
                .addFields(
                    { name: `**Ticket Channel**` , value: `<#${interaction.channel.id}> ( ${interaction.channel.name} )` },
                    { name: `**Closed By**` , value: `<@${interaction.user.id}> ( ${interaction.user.tag} ) ( ${interaction.user.id} )` },
                    { name: `**Closed Since**` , value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>` },
                    { name: `**Ticket Owner**` , value: `<@${ticketData.userID}> ( ${ticketData.userID} )` },
                    { name: `**Ticket Order**` , value: `${ticketData.order}` }
                )
                .setFooter({
                    text: interaction.guild.name,
                    iconURL: interaction.guild.iconURL({dynamic: true})
                })
                .setTimestamp();
            await client.channels.cache.get(logsChannel).send({embeds: [logsEmbed]});
        });
    }
});

client.on("interactionCreate" , async (interaction) => {
    if (!interaction.isCommand()) return;
    if (interaction.commandName === "delete") {
        if (!interaction.guild) return;
        if (!interaction.member.roles.cache.has(adminsRole)) return await interaction.reply({ content: `:warning: **You dont have access to do this action**`, ephemeral: true });
        let ticketData = await ticketModel.findOne({channelID: interaction.channel.id});
        if (!ticketData) return await interaction.reply({content: `:warning: **This channel is not a ticket.**` , ephemeral: true});
        await interaction.reply({content: ":warning: **This ticket will be deleted in 5s**"});
        await ticketData.delete();
        setTimeout(async() => {
            await interaction.channel.delete();
        } , 5000);
        let logsEmbed = new MessageEmbed()
            .setColor("RED")
            .setTitle(`**An ticket has been deleted**`)
            .addFields(
                { name: `**Ticket Channel**` , value: `<#${interaction.channel.id}> ( ${interaction.channel.name} )` },
                { name: `**Deleted By**` , value: `<@${interaction.user.id}> ( ${interaction.user.tag} ) ( ${interaction.user.id} )` },
                { name: `**Deleted Since**` , value: `<t:${Math.floor(interaction.createdTimestamp / 1000)}:R>` },
                { name: `**Ticket Owner**` , value: `<@${ticketData.userID}> ( ${ticketData.userID} )` },
                { name: `**Ticket Order**` , value: `${ticketData.order}` }
            )
            .setFooter({
                text: interaction.guild.name,
                iconURL: interaction.guild.iconURL({dynamic: true})
            })
            .setTimestamp();
        await client.channels.cache.get(logsChannel).send({embeds: [logsEmbed]});
    }
});

client.on("interactionCreate" , async (interaction) => {
    if (!interaction.isCommand()) return;
    if (interaction.commandName === "show-work") {
        if (!interaction.guild) return;
        if (!interaction.member.roles.cache.has(designersRole)) return await interaction.reply({content: `:warning: **This command is for our designers only**` , ephemeral: true});
        let designerWorkData = await designerWorksModel.findOne({userID: interaction.user.id});
        if (designerWorkData) return await interaction.reply({content: `:warning: **You used this command before.**` , ephemeral: true});
        if (!designerWorkData) {
            let designerWorkModal = new Modal()
            .setCustomId('designerWork')
            .setTitle('Your Works');
            let workWebsiteInput = new TextInputComponent()
            .setCustomId('workWebsiteInput')
            .setLabel("Behance, linkden, portofolio link")
            .setStyle('SHORT');
            let designerTypeInput = new TextInputComponent()
            .setCustomId('designerTypeInput')
            .setLabel("design types ( Discord, YouTube, etc. )")
            .setStyle('SHORT');
            let paymentMethodsInput = new TextInputComponent()
            .setCustomId('paymentMethodsInput')
            .setLabel("payment method ( PayPal, Credits, etc. )")
            .setStyle('SHORT');
            let workWebsiteActionRow = new MessageActionRow().addComponents(workWebsiteInput);
            let designerTypeActionRow = new MessageActionRow().addComponents(designerTypeInput);
            let paymentMethodsActionRow = new MessageActionRow().addComponents(paymentMethodsInput);
            designerWorkModal.addComponents(workWebsiteActionRow , designerTypeActionRow , paymentMethodsActionRow);
            await interaction.showModal(designerWorkModal);
        }
    }
});

client.on('interactionCreate', async(interaction) => {
    if (!interaction.isModalSubmit()) return;
    if (interaction.customId === "designerWork") {
        let designerWorkData = await designerWorksModel.findOne({userID: interaction.user.id});
        if (designerWorkData) return await interaction.reply({content: `:warning: **You used this command before.**` , ephemeral: true});
        let workWebsite = interaction.fields.getTextInputValue('workWebsiteInput');
        let designerType = interaction.fields.getTextInputValue('designerTypeInput');
        let paymentMethods = interaction.fields.getTextInputValue('paymentMethodsInput');
        let newDesignerWork = new designerWorksModel({
            userID: interaction.user.id,
            workWebsite: workWebsite,
            designerType: designerType,
            paymentMethods: paymentMethods
        });
        await newDesignerWork.save();
        let shareWorkEmbed = new MessageEmbed()
            .setColor("#441d92")
            .setAuthor({
                name: interaction.guild.name
            })
            .addFields(
                { name: `**The Designer :**` , value: `<@${interaction.user.id}> ( ${interaction.user.tag} ) ( ${interaction.user.id} )` },
                { name: `**His Works Link :**` , value: `${workWebsite}`},
                { name: `**He Can Deisgn :**` , value: `${designerType}`},
                { name: `**Payment Methods :**` , value: `${paymentMethods}`}
            )
            .setFooter({
                text: interaction.guild.name,
                iconURL: interaction.guild.iconURL({dynamic: true})
            })
            .setTimestamp();
        await client.channels.cache.get(designersWorkChannel).send({embeds: [shareWorkEmbed]}).then(async (msg) => {
            await msg.startThread({
                name: `${interaction.user.username}-works`,
                autoArchiveDuration: 60
            });
        });
        await interaction.reply({content: `:white_check_mark: **Your works has been shared.**` , ephemeral: true});
        let logsEmbed = new MessageEmbed()
            .setColor("GREEN")
            .setTitle(`**A new designer added his works**`)
            .addFields(
                { name: `**Designer**` , value: `<@${interaction.user.id}> ( ${interaction.user.tag} ) ( ${interaction.user.id} )` },
                { name: `**Designer Work Website**` , value: `${workWebsite}` },
                { name: `**Designer Type**` , value: `${designerType}` },
                { name: `**Designer Payment Methods**` , value: `${paymentMethods}` }
            )
            .setFooter({
                text: interaction.guild.name,
                iconURL: interaction.guild.iconURL({dynamic: true})
            })
            .setTimestamp();
        await client.channels.cache.get(logsChannel).send({embeds: [logsEmbed]});
    }
});

client.on("interactionCreate" , async(interaction) => {
    if (!interaction.isCommand()) return;
    if (interaction.commandName === "view-designer") {
        let User = interaction.options.getUser("user");
        let designerWorkData = await designerWorksModel.findOne({userID: User.id});
        if (!designerWorkData) return await interaction.reply({content: `:warning: **This user is not a designer**` , ephemeral: true});
        if (designerWorkData) {
            let viewDesignerEmbed = new MessageEmbed()
                .setColor("#441d92")
                .setAuthor({
                    name: interaction.guild.name
                })
                .addFields(
                    { name: `**The Designer :**` , value: `<@${User.id}> ( ${User.tag} ) ( ${User.id} )` },
                    { name: `**His Works Link :**` , value: `${designerWorkData.workWebsite}`},
                    { name: `**He Can Deisgn :**` , value: `${designerWorkData.designerType}`},
                    { name: `**Payment Methods :**` , value: `${designerWorkData.paymentMethods}`}
                )
                .setFooter({
                    text: interaction.guild.name,
                    iconURL: interaction.guild.iconURL({dynamic: true})
                })
                .setTimestamp();
            await interaction.reply({embeds: [viewDesignerEmbed] , ephemeral: true});
        }
    }
});

client.on("messageCreate", message => {
    let owners = ["744183251102335007"];
    if(!owners.includes(message.author.id)) return;
    let clean = text => {
        if (typeof(text) === "string")
            return text.replace(/`/g, "`" + String.fromCharCode(8203)).replace(/@/g, "@" + String.fromCharCode(8203));
        else
            return text;
    }    
    if(message.content.startsWith(prefix + "eval")){
        let code = message.content.split(" ").slice(1).join(" ");
        try {
            let evaled = eval(code);
            if(typeof evaled !== "string") evaled = require("util").inspect(evaled);
            message.channel.send(clean(evaled));
        } catch(err) {
            message.channel.send(`\`ERROR\` \`\`\`xl\n${clean(err)}\n\`\`\``);
        }
    }
});

client.on("ready", async () => {
    console.log(`logged in as [ ${client.user.tag} ]`);
});

client.login(token);