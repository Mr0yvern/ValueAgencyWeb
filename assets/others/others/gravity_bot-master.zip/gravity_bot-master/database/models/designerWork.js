const { model , Schema } = require('mongoose');

const designerWorkSchema = new Schema({
    userID: {
        type: String,
    },
    workWebsite: {
        type: String,
    },
    designerType: {
        type: String,
    },
    paymentMethods: {
        type: String,
    }
});

module.exports = model('DesignerWork', designerWorkSchema);