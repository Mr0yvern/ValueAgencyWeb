const { model , Schema } = require('mongoose');

const ticketSchema = new Schema({
    userID: {
        type: String,
    },
    order: {
        type: String,
    },
    channelID: {
        type: String,
    },
    messageID: {
        type: String,
    },
    designersOrderRole: {
        type: String,
    },
    cliamedBy: {
        type: String,
    },
    closed: {
        type: Boolean,
        default: false,
    }
});

module.exports = model('Tickets', ticketSchema);