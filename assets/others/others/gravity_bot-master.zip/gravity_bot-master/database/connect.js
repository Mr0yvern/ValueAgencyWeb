const mongoose = require('mongoose');
const config = require('../config.json');
mongoose.connect(config.mongoURL).then(() => {
    console.log('[ Database ] Connected to database');
}).catch(err => {
    console.log(err);
});